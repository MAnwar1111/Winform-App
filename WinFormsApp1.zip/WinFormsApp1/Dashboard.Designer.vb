﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TableLayoutPanel1 = New TableLayoutPanel()
        LinkLabel1 = New LinkLabel()
        InstructorProfiles = New LinkLabel()
        ViewReport = New LinkLabel()
        AutomatedProcesses = New LinkLabel()
        BookedLessons = New LinkLabel()
        Studentdetailslink = New LinkLabel()
        Panel1 = New Panel()
        Label1 = New Label()
        TableLayoutPanel2 = New TableLayoutPanel()
        Panel4 = New Panel()
        Label6 = New Label()
        Label8 = New Label()
        Label2 = New Label()
        Panel2 = New Panel()
        PictureBox1 = New PictureBox()
        Label5 = New Label()
        Panel3 = New Panel()
        Label7 = New Label()
        Label4 = New Label()
        TableLayoutPanel1.SuspendLayout()
        Panel1.SuspendLayout()
        TableLayoutPanel2.SuspendLayout()
        Panel4.SuspendLayout()
        Panel2.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel3.SuspendLayout()
        SuspendLayout()
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel1.ColumnCount = 1
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel1.Controls.Add(LinkLabel1, 0, 0)
        TableLayoutPanel1.Controls.Add(InstructorProfiles, 0, 2)
        TableLayoutPanel1.Controls.Add(ViewReport, 0, 4)
        TableLayoutPanel1.Controls.Add(AutomatedProcesses, 0, 5)
        TableLayoutPanel1.Controls.Add(BookedLessons, 0, 1)
        TableLayoutPanel1.Controls.Add(Studentdetailslink, 0, 3)
        TableLayoutPanel1.ForeColor = Color.Black
        TableLayoutPanel1.Location = New Point(13, 13)
        TableLayoutPanel1.Margin = New Padding(4)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 7
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.8225107F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 35.0649338F))
        TableLayoutPanel1.Size = New Size(267, 746)
        TableLayoutPanel1.TabIndex = 1
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel1.AutoSize = True
        LinkLabel1.Cursor = Cursors.Hand
        LinkLabel1.Font = New Font("Times New Roman", 12F)
        LinkLabel1.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel1.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel1.LinkColor = Color.Black
        LinkLabel1.Location = New Point(15, 9)
        LinkLabel1.Margin = New Padding(14, 8, 14, 8)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(237, 63)
        LinkLabel1.TabIndex = 0
        LinkLabel1.TabStop = True
        LinkLabel1.Text = "Dashboard"
        LinkLabel1.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' InstructorProfiles
        ' 
        InstructorProfiles.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        InstructorProfiles.AutoSize = True
        InstructorProfiles.Cursor = Cursors.Hand
        InstructorProfiles.Font = New Font("Times New Roman", 12F)
        InstructorProfiles.ForeColor = SystemColors.ActiveCaptionText
        InstructorProfiles.LinkBehavior = LinkBehavior.HoverUnderline
        InstructorProfiles.LinkColor = Color.Black
        InstructorProfiles.Location = New Point(15, 169)
        InstructorProfiles.Margin = New Padding(14, 8, 14, 8)
        InstructorProfiles.Name = "InstructorProfiles"
        InstructorProfiles.Size = New Size(237, 63)
        InstructorProfiles.TabIndex = 2
        InstructorProfiles.TabStop = True
        InstructorProfiles.Text = "Instructor Profiles"
        InstructorProfiles.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' ViewReport
        ' 
        ViewReport.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        ViewReport.AutoSize = True
        ViewReport.Cursor = Cursors.Hand
        ViewReport.Font = New Font("Times New Roman", 12F)
        ViewReport.ForeColor = SystemColors.ActiveCaptionText
        ViewReport.LinkBehavior = LinkBehavior.HoverUnderline
        ViewReport.LinkColor = Color.Black
        ViewReport.Location = New Point(15, 329)
        ViewReport.Margin = New Padding(14, 8, 14, 8)
        ViewReport.Name = "ViewReport"
        ViewReport.Size = New Size(237, 63)
        ViewReport.TabIndex = 4
        ViewReport.TabStop = True
        ViewReport.Text = "View Reports/Analytics"
        ViewReport.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' AutomatedProcesses
        ' 
        AutomatedProcesses.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        AutomatedProcesses.AutoSize = True
        AutomatedProcesses.Cursor = Cursors.Hand
        AutomatedProcesses.Font = New Font("Times New Roman", 12F)
        AutomatedProcesses.ForeColor = SystemColors.ActiveCaptionText
        AutomatedProcesses.LinkBehavior = LinkBehavior.HoverUnderline
        AutomatedProcesses.LinkColor = Color.Black
        AutomatedProcesses.Location = New Point(15, 409)
        AutomatedProcesses.Margin = New Padding(14, 8, 14, 8)
        AutomatedProcesses.Name = "AutomatedProcesses"
        AutomatedProcesses.Size = New Size(237, 63)
        AutomatedProcesses.TabIndex = 5
        AutomatedProcesses.TabStop = True
        AutomatedProcesses.Text = "Automated Processes"
        AutomatedProcesses.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' BookedLessons
        ' 
        BookedLessons.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        BookedLessons.AutoSize = True
        BookedLessons.Cursor = Cursors.Hand
        BookedLessons.Font = New Font("Times New Roman", 12F)
        BookedLessons.ForeColor = SystemColors.ActiveCaptionText
        BookedLessons.LinkBehavior = LinkBehavior.HoverUnderline
        BookedLessons.LinkColor = Color.Black
        BookedLessons.Location = New Point(15, 89)
        BookedLessons.Margin = New Padding(14, 8, 14, 8)
        BookedLessons.Name = "BookedLessons"
        BookedLessons.Size = New Size(237, 63)
        BookedLessons.TabIndex = 3
        BookedLessons.TabStop = True
        BookedLessons.Text = "Book Lessons"
        BookedLessons.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Studentdetailslink
        ' 
        Studentdetailslink.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Studentdetailslink.AutoSize = True
        Studentdetailslink.Cursor = Cursors.Hand
        Studentdetailslink.Font = New Font("Times New Roman", 12F)
        Studentdetailslink.ForeColor = SystemColors.ActiveCaptionText
        Studentdetailslink.LinkBehavior = LinkBehavior.HoverUnderline
        Studentdetailslink.LinkColor = Color.Black
        Studentdetailslink.Location = New Point(15, 249)
        Studentdetailslink.Margin = New Padding(14, 8, 14, 8)
        Studentdetailslink.Name = "Studentdetailslink"
        Studentdetailslink.Size = New Size(237, 63)
        Studentdetailslink.TabIndex = 1
        Studentdetailslink.TabStop = True
        Studentdetailslink.Text = "Student Profiles"
        Studentdetailslink.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Panel1
        ' 
        Panel1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(287, 13)
        Panel1.Margin = New Padding(3, 4, 3, 4)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(768, 89)
        Panel1.TabIndex = 2
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(3, 30)
        Label1.Name = "Label1"
        Label1.Size = New Size(135, 33)
        Label1.TabIndex = 0
        Label1.Text = "Dashboard"
        Label1.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' TableLayoutPanel2
        ' 
        TableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel2.ColumnCount = 1
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel2.Controls.Add(Panel4, 0, 3)
        TableLayoutPanel2.Controls.Add(Label2, 0, 1)
        TableLayoutPanel2.Controls.Add(Panel2, 0, 0)
        TableLayoutPanel2.Controls.Add(Panel3, 0, 2)
        TableLayoutPanel2.Location = New Point(287, 109)
        TableLayoutPanel2.Name = "TableLayoutPanel2"
        TableLayoutPanel2.RowCount = 4
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 18.965517F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 10.9717865F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 36.0501556F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 34.01254F))
        TableLayoutPanel2.Size = New Size(768, 639)
        TableLayoutPanel2.TabIndex = 3
        ' 
        ' Panel4
        ' 
        Panel4.Controls.Add(Label6)
        Panel4.Controls.Add(Label8)
        Panel4.Location = New Point(4, 424)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(760, 211)
        Panel4.TabIndex = 5
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(6, 34)
        Label6.Name = "Label6"
        Label6.Size = New Size(580, 66)
        Label6.TabIndex = 4
        Label6.Text = "Find the best time that fits your schedule. Explore the availability and " & vbLf & "Upcoming schedules of our dedicated instructors, making it easy to plan " & vbLf & "your lessons."
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(3, 1)
        Label8.Name = "Label8"
        Label8.Size = New Size(178, 22)
        Label8.TabIndex = 2
        Label8.Text = "Instructure Schedules"
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label2.AutoSize = True
        Label2.Font = New Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(4, 122)
        Label2.Name = "Label2"
        Label2.Size = New Size(216, 69)
        Label2.TabIndex = 0
        Label2.Text = "Summary Widgets"
        Label2.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Panel2
        ' 
        Panel2.Controls.Add(PictureBox1)
        Panel2.Controls.Add(Label5)
        Panel2.Location = New Point(4, 4)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(760, 114)
        Panel2.TabIndex = 3
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.original_red_24177_960_720
        PictureBox1.Location = New Point(612, 9)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(66, 87)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 1
        PictureBox1.TabStop = False
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(6, 9)
        Label5.Name = "Label5"
        Label5.Size = New Size(489, 88)
        Label5.TabIndex = 0
        Label5.Text = "Welcome Users," & vbLf & "Great to see you! You're now logged in to DriveEaseHub." & vbLf & "Explore, manage lessons, track process, and more from here." & vbLf & "Have a fantastic day of Driving!"
        ' 
        ' Panel3
        ' 
        Panel3.Controls.Add(Label7)
        Panel3.Controls.Add(Label4)
        Panel3.Location = New Point(4, 195)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(760, 222)
        Panel3.TabIndex = 4
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(6, 35)
        Label7.Name = "Label7"
        Label7.Size = New Size(618, 66)
        Label7.TabIndex = 4
        Label7.Text = "Stay on track with your driving schedules. Our system provides a convenient " & vbLf & "snapshot of your upcoming lessons, ensuring you're always prepared for " & vbLf & "your next session."
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(3, 1)
        Label4.Name = "Label4"
        Label4.Size = New Size(158, 22)
        Label4.TabIndex = 2
        Label4.Text = "Upcoming Lessons"
        ' 
        ' Dashboard
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.MediumTurquoise
        ClientSize = New Size(1098, 760)
        Controls.Add(TableLayoutPanel2)
        Controls.Add(Panel1)
        Controls.Add(TableLayoutPanel1)
        Name = "Dashboard"
        Text = "Form1"
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel1.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        TableLayoutPanel2.ResumeLayout(False)
        TableLayoutPanel2.PerformLayout()
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents InstructorProfiles As LinkLabel
    Friend WithEvents ViewReport As LinkLabel
    Friend WithEvents AutomatedProcesses As LinkLabel
    Friend WithEvents BookedLessons As LinkLabel
    Friend WithEvents Studentdetailslink As LinkLabel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
End Class
