﻿Public Class Booklessons
    Private Sub LinkLabel4_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Dashboard.LinkClicked
        Me.Hide()

        ' Create an instance of Form2 and show it
        Dim form2 As New Booklessons()
        form2.Show()
    End Sub

    Private Sub LinkLabel8_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles BookedLessons.LinkClicked
        ' Hide the current form (Form1)
        Me.Hide()

        ' Create an instance of Form2 and show it
        Dim form2 As New Booklessons()
        form2.Show()
    End Sub

    Private Sub LinkLabel5_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Studentdetailpage.LinkClicked
        ' Hide the current form (Form1)
        Me.Hide()

        ' Create an instance of Form2 and show it
        Dim form2 As New Instructuredetails()
        form2.Show()
    End Sub

    Private Sub Studentdetailslink_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Studentdetailslink.LinkClicked
        ' Hide the current form (Form1)
        Me.Hide()

        ' Create an instance of Form2 and show it
        Dim form2 As New Studentdetailes()
        form2.Show()
    End Sub

    Private Sub ViewReport_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles ViewReport.LinkClicked
        ' Hide the current form (Form1)
        Me.Hide()

        ' Create an instance of Form2 and show it
        Dim form2 As New Studentprogress()
        form2.Show()
    End Sub

    Private Sub AutomatedProcesses_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles AutomatedProcesses.LinkClicked
        ' Hide the current form (Form1)
        Me.Hide()

        ' Create an instance of Form2 and show it
        Dim form2 As New Processingltudentleaving()
        form2.Show()
    End Sub
End Class