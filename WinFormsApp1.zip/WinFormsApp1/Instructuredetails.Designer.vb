﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Instructuredetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Button5 = New Button()
        PictureBox1 = New PictureBox()
        Panel2 = New Panel()
        PictureBox2 = New PictureBox()
        TextBox1 = New TextBox()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label1 = New Label()
        Panel1 = New Panel()
        Dashboard = New LinkLabel()
        LinkLabel3 = New LinkLabel()
        ViewReport = New LinkLabel()
        AutomatedProcesses = New LinkLabel()
        BookedLessons = New LinkLabel()
        Studentdetailpage = New LinkLabel()
        TableLayoutPanel1 = New TableLayoutPanel()
        Button4 = New Button()
        TableLayoutPanel2 = New TableLayoutPanel()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel2.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        TableLayoutPanel1.SuspendLayout()
        TableLayoutPanel2.SuspendLayout()
        SuspendLayout()
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Label5.AutoSize = True
        Label5.Location = New Point(4, 333)
        Label5.Name = "Label5"
        Label5.Size = New Size(136, 82)
        Label5.TabIndex = 3
        Label5.Text = "4."
        Label5.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label6
        ' 
        Label6.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Label6.AutoSize = True
        Label6.Location = New Point(4, 416)
        Label6.Name = "Label6"
        Label6.Size = New Size(136, 82)
        Label6.TabIndex = 4
        Label6.Text = "5."
        Label6.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Label7.AutoSize = True
        Label7.Location = New Point(147, 1)
        Label7.Name = "Label7"
        Label7.Size = New Size(136, 82)
        Label7.TabIndex = 5
        Label7.Text = "Name"
        Label7.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Label8.AutoSize = True
        Label8.Location = New Point(290, 1)
        Label8.Name = "Label8"
        Label8.Size = New Size(136, 82)
        Label8.TabIndex = 6
        Label8.Text = "Class"
        Label8.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label9
        ' 
        Label9.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Label9.AutoSize = True
        Label9.Location = New Point(433, 1)
        Label9.Name = "Label9"
        Label9.Size = New Size(136, 82)
        Label9.TabIndex = 7
        Label9.Text = "Roll"
        Label9.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Button1
        ' 
        Button1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Button1.Location = New Point(576, 88)
        Button1.Margin = New Padding(3, 4, 3, 4)
        Button1.Name = "Button1"
        Button1.Size = New Size(136, 74)
        Button1.TabIndex = 8
        Button1.Text = "Edit"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Button2.Location = New Point(576, 171)
        Button2.Margin = New Padding(3, 4, 3, 4)
        Button2.Name = "Button2"
        Button2.Size = New Size(136, 74)
        Button2.TabIndex = 9
        Button2.Text = "Edit"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Button3.Location = New Point(576, 254)
        Button3.Margin = New Padding(3, 4, 3, 4)
        Button3.Name = "Button3"
        Button3.Size = New Size(136, 74)
        Button3.TabIndex = 10
        Button3.Text = "Edit"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Button5.Location = New Point(576, 420)
        Button5.Margin = New Padding(3, 4, 3, 4)
        Button5.Name = "Button5"
        Button5.Size = New Size(136, 74)
        Button5.TabIndex = 12
        Button5.Text = "Edit"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.icons8_filter_48
        PictureBox1.Location = New Point(655, 24)
        PictureBox1.Margin = New Padding(3, 4, 3, 4)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(39, 41)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 2
        PictureBox1.TabStop = False
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.White
        Panel2.Controls.Add(PictureBox2)
        Panel2.Controls.Add(TextBox1)
        Panel2.Location = New Point(254, 24)
        Panel2.Margin = New Padding(3, 4, 3, 4)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(395, 50)
        Panel2.TabIndex = 2
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = My.Resources.Resources.icons8_search_48
        PictureBox2.Location = New Point(3, 5)
        PictureBox2.Margin = New Padding(3, 4, 3, 4)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(42, 41)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 2
        PictureBox2.TabStop = False
        ' 
        ' TextBox1
        ' 
        TextBox1.BorderStyle = BorderStyle.None
        TextBox1.Location = New Point(51, 12)
        TextBox1.Margin = New Padding(3, 4, 3, 4)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(341, 20)
        TextBox1.TabIndex = 1
        TextBox1.Text = "Search"
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Label2.AutoSize = True
        Label2.Location = New Point(4, 84)
        Label2.Name = "Label2"
        Label2.Size = New Size(136, 82)
        Label2.TabIndex = 0
        Label2.Text = "1."
        Label2.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Label3.AutoSize = True
        Label3.Location = New Point(4, 167)
        Label3.Name = "Label3"
        Label3.Size = New Size(136, 82)
        Label3.TabIndex = 1
        Label3.Text = "2."
        Label3.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Label4.AutoSize = True
        Label4.Location = New Point(4, 250)
        Label4.Name = "Label4"
        Label4.Size = New Size(136, 82)
        Label4.TabIndex = 2
        Label4.Text = "3."
        Label4.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(3, 32)
        Label1.Name = "Label1"
        Label1.Size = New Size(220, 33)
        Label1.TabIndex = 0
        Label1.Text = "Instructure Details"
        Label1.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Panel1
        ' 
        Panel1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Controls.Add(PictureBox1)
        Panel1.Controls.Add(Panel2)
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(385, 13)
        Panel1.Margin = New Padding(3, 4, 3, 4)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(716, 103)
        Panel1.TabIndex = 4
        ' 
        ' Dashboard
        ' 
        Dashboard.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Dashboard.AutoSize = True
        Dashboard.Cursor = Cursors.Hand
        Dashboard.Font = New Font("Times New Roman", 12F)
        Dashboard.ForeColor = SystemColors.ActiveCaptionText
        Dashboard.LinkBehavior = LinkBehavior.HoverUnderline
        Dashboard.LinkColor = Color.Black
        Dashboard.Location = New Point(15, 9)
        Dashboard.Margin = New Padding(14, 8, 14, 8)
        Dashboard.Name = "Dashboard"
        Dashboard.Size = New Size(335, 67)
        Dashboard.TabIndex = 0
        Dashboard.TabStop = True
        Dashboard.Text = "Dashboard"
        Dashboard.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' LinkLabel3
        ' 
        LinkLabel3.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel3.AutoSize = True
        LinkLabel3.Cursor = Cursors.Hand
        LinkLabel3.Font = New Font("Times New Roman", 12F)
        LinkLabel3.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel3.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel3.LinkColor = Color.Black
        LinkLabel3.Location = New Point(15, 177)
        LinkLabel3.Margin = New Padding(14, 8, 14, 8)
        LinkLabel3.Name = "LinkLabel3"
        LinkLabel3.Size = New Size(335, 67)
        LinkLabel3.TabIndex = 2
        LinkLabel3.TabStop = True
        LinkLabel3.Text = "Instructor Profiles"
        LinkLabel3.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' ViewReport
        ' 
        ViewReport.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        ViewReport.AutoSize = True
        ViewReport.Cursor = Cursors.Hand
        ViewReport.Font = New Font("Times New Roman", 12F)
        ViewReport.ForeColor = SystemColors.ActiveCaptionText
        ViewReport.LinkBehavior = LinkBehavior.HoverUnderline
        ViewReport.LinkColor = Color.Black
        ViewReport.Location = New Point(15, 345)
        ViewReport.Margin = New Padding(14, 8, 14, 8)
        ViewReport.Name = "ViewReport"
        ViewReport.Size = New Size(335, 67)
        ViewReport.TabIndex = 4
        ViewReport.TabStop = True
        ViewReport.Text = "View Reports/Analytics"
        ViewReport.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' AutomatedProcesses
        ' 
        AutomatedProcesses.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        AutomatedProcesses.AutoSize = True
        AutomatedProcesses.Cursor = Cursors.Hand
        AutomatedProcesses.Font = New Font("Times New Roman", 12F)
        AutomatedProcesses.ForeColor = SystemColors.ActiveCaptionText
        AutomatedProcesses.LinkBehavior = LinkBehavior.HoverUnderline
        AutomatedProcesses.LinkColor = Color.Black
        AutomatedProcesses.Location = New Point(15, 429)
        AutomatedProcesses.Margin = New Padding(14, 8, 14, 8)
        AutomatedProcesses.Name = "AutomatedProcesses"
        AutomatedProcesses.Size = New Size(335, 67)
        AutomatedProcesses.TabIndex = 5
        AutomatedProcesses.TabStop = True
        AutomatedProcesses.Text = "Automated Processes"
        AutomatedProcesses.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' BookedLessons
        ' 
        BookedLessons.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        BookedLessons.AutoSize = True
        BookedLessons.Cursor = Cursors.Hand
        BookedLessons.Font = New Font("Times New Roman", 12F)
        BookedLessons.ForeColor = SystemColors.ActiveCaptionText
        BookedLessons.LinkBehavior = LinkBehavior.HoverUnderline
        BookedLessons.LinkColor = Color.Black
        BookedLessons.Location = New Point(15, 93)
        BookedLessons.Margin = New Padding(14, 8, 14, 8)
        BookedLessons.Name = "BookedLessons"
        BookedLessons.Size = New Size(335, 67)
        BookedLessons.TabIndex = 3
        BookedLessons.TabStop = True
        BookedLessons.Text = "Book Lessons"
        BookedLessons.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Studentdetailpage
        ' 
        Studentdetailpage.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Studentdetailpage.AutoSize = True
        Studentdetailpage.Cursor = Cursors.Hand
        Studentdetailpage.Font = New Font("Times New Roman", 12F)
        Studentdetailpage.ForeColor = SystemColors.ActiveCaptionText
        Studentdetailpage.LinkBehavior = LinkBehavior.HoverUnderline
        Studentdetailpage.LinkColor = Color.Black
        Studentdetailpage.Location = New Point(15, 261)
        Studentdetailpage.Margin = New Padding(14, 8, 14, 8)
        Studentdetailpage.Name = "Studentdetailpage"
        Studentdetailpage.Size = New Size(335, 67)
        Studentdetailpage.TabIndex = 1
        Studentdetailpage.TabStop = True
        Studentdetailpage.Text = "Student Profiles"
        Studentdetailpage.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel1.ColumnCount = 1
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel1.Controls.Add(Dashboard, 0, 0)
        TableLayoutPanel1.Controls.Add(LinkLabel3, 0, 2)
        TableLayoutPanel1.Controls.Add(ViewReport, 0, 4)
        TableLayoutPanel1.Controls.Add(AutomatedProcesses, 0, 5)
        TableLayoutPanel1.Controls.Add(BookedLessons, 0, 1)
        TableLayoutPanel1.Controls.Add(Studentdetailpage, 0, 3)
        TableLayoutPanel1.ForeColor = Color.Black
        TableLayoutPanel1.Location = New Point(13, 13)
        TableLayoutPanel1.Margin = New Padding(4)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 7
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.8225107F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 35.0649338F))
        TableLayoutPanel1.Size = New Size(365, 777)
        TableLayoutPanel1.TabIndex = 3
        ' 
        ' Button4
        ' 
        Button4.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Button4.Location = New Point(576, 337)
        Button4.Margin = New Padding(3, 4, 3, 4)
        Button4.Name = "Button4"
        Button4.Size = New Size(136, 74)
        Button4.TabIndex = 11
        Button4.Text = "Edit"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' TableLayoutPanel2
        ' 
        TableLayoutPanel2.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        TableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel2.ColumnCount = 5
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel2.Controls.Add(Label2, 0, 1)
        TableLayoutPanel2.Controls.Add(Label3, 0, 2)
        TableLayoutPanel2.Controls.Add(Label4, 0, 3)
        TableLayoutPanel2.Controls.Add(Label5, 0, 4)
        TableLayoutPanel2.Controls.Add(Label6, 0, 5)
        TableLayoutPanel2.Controls.Add(Label7, 1, 0)
        TableLayoutPanel2.Controls.Add(Label8, 2, 0)
        TableLayoutPanel2.Controls.Add(Label9, 3, 0)
        TableLayoutPanel2.Controls.Add(Button1, 4, 1)
        TableLayoutPanel2.Controls.Add(Button2, 4, 2)
        TableLayoutPanel2.Controls.Add(Button3, 4, 3)
        TableLayoutPanel2.Controls.Add(Button4, 4, 4)
        TableLayoutPanel2.Controls.Add(Button5, 4, 5)
        TableLayoutPanel2.Location = New Point(385, 122)
        TableLayoutPanel2.Margin = New Padding(3, 4, 3, 4)
        TableLayoutPanel2.Name = "TableLayoutPanel2"
        TableLayoutPanel2.RowCount = 7
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 12.5F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 12.5F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 12.5F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 12.5F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 12.5F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 12.5F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 25F))
        TableLayoutPanel2.Size = New Size(716, 668)
        TableLayoutPanel2.TabIndex = 5
        ' 
        ' Instructuredetails
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.MediumTurquoise
        ClientSize = New Size(1115, 841)
        Controls.Add(Panel1)
        Controls.Add(TableLayoutPanel1)
        Controls.Add(TableLayoutPanel2)
        Name = "Instructuredetails"
        Text = "Form1"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel1.PerformLayout()
        TableLayoutPanel2.ResumeLayout(False)
        TableLayoutPanel2.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Dashboard As LinkLabel
    Friend WithEvents LinkLabel3 As LinkLabel
    Friend WithEvents ViewReport As LinkLabel
    Friend WithEvents AutomatedProcesses As LinkLabel
    Friend WithEvents BookedLessons As LinkLabel
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Button4 As Button
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Studentdetailslink As LinkLabel
    Friend WithEvents Studentdetailpage As LinkLabel
End Class
