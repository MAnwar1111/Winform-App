﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Processingltudentleaving
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TableLayoutPanel1 = New TableLayoutPanel()
        LinkLabel1 = New LinkLabel()
        InstructorProfiles = New LinkLabel()
        TableLayoutPanel2 = New TableLayoutPanel()
        LinkLabel2 = New LinkLabel()
        LinkLabel3 = New LinkLabel()
        LinkLabel5 = New LinkLabel()
        LinkLabel6 = New LinkLabel()
        LinkLabel4 = New LinkLabel()
        Studentdetailslink = New LinkLabel()
        Panel1 = New Panel()
        Label1 = New Label()
        TableLayoutPanel3 = New TableLayoutPanel()
        Panel8 = New Panel()
        Label8 = New Label()
        PictureBox5 = New PictureBox()
        Label7 = New Label()
        Panel5 = New Panel()
        CheckBox3 = New CheckBox()
        CheckBox2 = New CheckBox()
        CheckBox1 = New CheckBox()
        Panel6 = New Panel()
        Label5 = New Label()
        PictureBox3 = New PictureBox()
        Panel7 = New Panel()
        Label6 = New Label()
        PictureBox4 = New PictureBox()
        Label4 = New Label()
        Panel3 = New Panel()
        Panel4 = New Panel()
        Label3 = New Label()
        PictureBox2 = New PictureBox()
        Panel2 = New Panel()
        Label2 = New Label()
        PictureBox1 = New PictureBox()
        TableLayoutPanel1.SuspendLayout()
        TableLayoutPanel2.SuspendLayout()
        Panel1.SuspendLayout()
        TableLayoutPanel3.SuspendLayout()
        Panel8.SuspendLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        Panel5.SuspendLayout()
        Panel6.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        Panel7.SuspendLayout()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        Panel3.SuspendLayout()
        Panel4.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        Panel2.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel1.ColumnCount = 1
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel1.Controls.Add(LinkLabel1, 0, 0)
        TableLayoutPanel1.Location = New Point(0, 0)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 2
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel1.Size = New Size(200, 100)
        TableLayoutPanel1.TabIndex = 0
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel1.AutoSize = True
        LinkLabel1.Cursor = Cursors.Hand
        LinkLabel1.Font = New Font("Times New Roman", 12F)
        LinkLabel1.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel1.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel1.LinkColor = Color.Black
        LinkLabel1.Location = New Point(15, 9)
        LinkLabel1.Margin = New Padding(14, 8, 14, 8)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(170, 4)
        LinkLabel1.TabIndex = 0
        LinkLabel1.TabStop = True
        LinkLabel1.Text = "Dashboard"
        LinkLabel1.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' InstructorProfiles
        ' 
        InstructorProfiles.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        InstructorProfiles.AutoSize = True
        InstructorProfiles.Cursor = Cursors.Hand
        InstructorProfiles.Font = New Font("Times New Roman", 12F)
        InstructorProfiles.ForeColor = SystemColors.ActiveCaptionText
        InstructorProfiles.LinkBehavior = LinkBehavior.HoverUnderline
        InstructorProfiles.LinkColor = Color.Black
        InstructorProfiles.Location = New Point(15, 49)
        InstructorProfiles.Margin = New Padding(14, 8, 14, 8)
        InstructorProfiles.Name = "InstructorProfiles"
        InstructorProfiles.Size = New Size(170, 42)
        InstructorProfiles.TabIndex = 2
        InstructorProfiles.TabStop = True
        InstructorProfiles.Text = "Instructor Profiles"
        InstructorProfiles.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' TableLayoutPanel2
        ' 
        TableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel2.ColumnCount = 1
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel2.Controls.Add(LinkLabel2, 0, 0)
        TableLayoutPanel2.Controls.Add(LinkLabel3, 0, 2)
        TableLayoutPanel2.Controls.Add(LinkLabel5, 0, 4)
        TableLayoutPanel2.Controls.Add(LinkLabel6, 0, 5)
        TableLayoutPanel2.Controls.Add(LinkLabel4, 0, 1)
        TableLayoutPanel2.Controls.Add(Studentdetailslink, 0, 3)
        TableLayoutPanel2.ForeColor = Color.Black
        TableLayoutPanel2.Location = New Point(13, 13)
        TableLayoutPanel2.Margin = New Padding(4)
        TableLayoutPanel2.Name = "TableLayoutPanel2"
        TableLayoutPanel2.RowCount = 7
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 10.8225107F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 35.0649338F))
        TableLayoutPanel2.Size = New Size(267, 746)
        TableLayoutPanel2.TabIndex = 2
        ' 
        ' LinkLabel2
        ' 
        LinkLabel2.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel2.AutoSize = True
        LinkLabel2.Cursor = Cursors.Hand
        LinkLabel2.Font = New Font("Times New Roman", 12F)
        LinkLabel2.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel2.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel2.LinkColor = Color.Black
        LinkLabel2.Location = New Point(15, 9)
        LinkLabel2.Margin = New Padding(14, 8, 14, 8)
        LinkLabel2.Name = "LinkLabel2"
        LinkLabel2.Size = New Size(237, 63)
        LinkLabel2.TabIndex = 0
        LinkLabel2.TabStop = True
        LinkLabel2.Text = "Dashboard"
        LinkLabel2.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' LinkLabel3
        ' 
        LinkLabel3.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel3.AutoSize = True
        LinkLabel3.Cursor = Cursors.Hand
        LinkLabel3.Font = New Font("Times New Roman", 12F)
        LinkLabel3.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel3.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel3.LinkColor = Color.Black
        LinkLabel3.Location = New Point(15, 169)
        LinkLabel3.Margin = New Padding(14, 8, 14, 8)
        LinkLabel3.Name = "LinkLabel3"
        LinkLabel3.Size = New Size(237, 63)
        LinkLabel3.TabIndex = 2
        LinkLabel3.TabStop = True
        LinkLabel3.Text = "Instructor Profiles"
        LinkLabel3.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' LinkLabel5
        ' 
        LinkLabel5.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel5.AutoSize = True
        LinkLabel5.Cursor = Cursors.Hand
        LinkLabel5.Font = New Font("Times New Roman", 12F)
        LinkLabel5.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel5.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel5.LinkColor = Color.Black
        LinkLabel5.Location = New Point(15, 329)
        LinkLabel5.Margin = New Padding(14, 8, 14, 8)
        LinkLabel5.Name = "LinkLabel5"
        LinkLabel5.Size = New Size(237, 63)
        LinkLabel5.TabIndex = 4
        LinkLabel5.TabStop = True
        LinkLabel5.Text = "View Reports/Analytics"
        LinkLabel5.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' LinkLabel6
        ' 
        LinkLabel6.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel6.AutoSize = True
        LinkLabel6.Cursor = Cursors.Hand
        LinkLabel6.Font = New Font("Times New Roman", 12F)
        LinkLabel6.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel6.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel6.LinkColor = Color.Black
        LinkLabel6.Location = New Point(15, 409)
        LinkLabel6.Margin = New Padding(14, 8, 14, 8)
        LinkLabel6.Name = "LinkLabel6"
        LinkLabel6.Size = New Size(237, 63)
        LinkLabel6.TabIndex = 5
        LinkLabel6.TabStop = True
        LinkLabel6.Text = "Automated Processes"
        LinkLabel6.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' LinkLabel4
        ' 
        LinkLabel4.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel4.AutoSize = True
        LinkLabel4.Cursor = Cursors.Hand
        LinkLabel4.Font = New Font("Times New Roman", 12F)
        LinkLabel4.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel4.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel4.LinkColor = Color.Black
        LinkLabel4.Location = New Point(15, 89)
        LinkLabel4.Margin = New Padding(14, 8, 14, 8)
        LinkLabel4.Name = "LinkLabel4"
        LinkLabel4.Size = New Size(237, 63)
        LinkLabel4.TabIndex = 3
        LinkLabel4.TabStop = True
        LinkLabel4.Text = "Book Lessons"
        LinkLabel4.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Studentdetailslink
        ' 
        Studentdetailslink.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Studentdetailslink.AutoSize = True
        Studentdetailslink.Cursor = Cursors.Hand
        Studentdetailslink.Font = New Font("Times New Roman", 12F)
        Studentdetailslink.ForeColor = SystemColors.ActiveCaptionText
        Studentdetailslink.LinkBehavior = LinkBehavior.HoverUnderline
        Studentdetailslink.LinkColor = Color.Black
        Studentdetailslink.Location = New Point(15, 249)
        Studentdetailslink.Margin = New Padding(14, 8, 14, 8)
        Studentdetailslink.Name = "Studentdetailslink"
        Studentdetailslink.Size = New Size(237, 63)
        Studentdetailslink.TabIndex = 1
        Studentdetailslink.TabStop = True
        Studentdetailslink.Text = "Student Profiles"
        Studentdetailslink.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Panel1
        ' 
        Panel1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(287, 13)
        Panel1.Margin = New Padding(3, 4, 3, 4)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(768, 89)
        Panel1.TabIndex = 4
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(3, 30)
        Label1.Name = "Label1"
        Label1.Size = New Size(322, 33)
        Label1.TabIndex = 0
        Label1.Text = "Processing Student Leaving"
        Label1.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' TableLayoutPanel3
        ' 
        TableLayoutPanel3.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel3.ColumnCount = 1
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel3.Controls.Add(Panel8, 0, 4)
        TableLayoutPanel3.Controls.Add(Label7, 0, 3)
        TableLayoutPanel3.Controls.Add(Panel5, 0, 2)
        TableLayoutPanel3.Controls.Add(Label4, 0, 1)
        TableLayoutPanel3.Controls.Add(Panel3, 0, 0)
        TableLayoutPanel3.Location = New Point(287, 109)
        TableLayoutPanel3.Name = "TableLayoutPanel3"
        TableLayoutPanel3.RowCount = 5
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 30F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 10F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 30F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 10F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 20F))
        TableLayoutPanel3.Size = New Size(768, 650)
        TableLayoutPanel3.TabIndex = 5
        ' 
        ' Panel8
        ' 
        Panel8.Controls.Add(Label8)
        Panel8.Controls.Add(PictureBox5)
        Panel8.Location = New Point(4, 522)
        Panel8.Name = "Panel8"
        Panel8.Size = New Size(331, 63)
        Panel8.TabIndex = 5
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(59, 18)
        Label8.Name = "Label8"
        Label8.Size = New Size(193, 26)
        Label8.TabIndex = 1
        Label8.Text = "Scheduled Analysis"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Image = My.Resources.Resources.icons8_play_50
        PictureBox5.Location = New Point(3, 3)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(51, 53)
        PictureBox5.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox5.TabIndex = 0
        PictureBox5.TabStop = False
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label7.AutoSize = True
        Label7.Font = New Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(4, 454)
        Label7.Name = "Label7"
        Label7.Size = New Size(410, 64)
        Label7.TabIndex = 4
        Label7.Text = "Automated Analysis and Reporting:"
        Label7.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Panel5
        ' 
        Panel5.Controls.Add(CheckBox3)
        Panel5.Controls.Add(CheckBox2)
        Panel5.Controls.Add(CheckBox1)
        Panel5.Controls.Add(Panel6)
        Panel5.Controls.Add(Panel7)
        Panel5.Location = New Point(4, 263)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(760, 187)
        Panel5.TabIndex = 3
        ' 
        ' CheckBox3
        ' 
        CheckBox3.AutoSize = True
        CheckBox3.Location = New Point(417, 150)
        CheckBox3.Name = "CheckBox3"
        CheckBox3.Size = New Size(67, 24)
        CheckBox3.TabIndex = 5
        CheckBox3.Text = "dates"
        CheckBox3.UseVisualStyleBackColor = True
        ' 
        ' CheckBox2
        ' 
        CheckBox2.AutoSize = True
        CheckBox2.Location = New Point(234, 150)
        CheckBox2.Name = "CheckBox2"
        CheckBox2.Size = New Size(100, 24)
        CheckBox2.TabIndex = 4
        CheckBox2.Text = "instructure"
        CheckBox2.UseVisualStyleBackColor = True
        ' 
        ' CheckBox1
        ' 
        CheckBox1.AutoSize = True
        CheckBox1.Location = New Point(69, 150)
        CheckBox1.Name = "CheckBox1"
        CheckBox1.Size = New Size(66, 24)
        CheckBox1.TabIndex = 3
        CheckBox1.Text = "types"
        CheckBox1.UseVisualStyleBackColor = True
        ' 
        ' Panel6
        ' 
        Panel6.Controls.Add(Label5)
        Panel6.Controls.Add(PictureBox3)
        Panel6.Location = New Point(4, 72)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(331, 63)
        Panel6.TabIndex = 2
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(59, 18)
        Label5.Name = "Label5"
        Label5.Size = New Size(263, 26)
        Label5.TabIndex = 1
        Label5.Text = "Organization by Categories"
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Image = My.Resources.Resources.icons8_play_50
        PictureBox3.Location = New Point(3, 3)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(51, 53)
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.TabIndex = 0
        PictureBox3.TabStop = False
        ' 
        ' Panel7
        ' 
        Panel7.Controls.Add(Label6)
        Panel7.Controls.Add(PictureBox4)
        Panel7.Location = New Point(3, 3)
        Panel7.Name = "Panel7"
        Panel7.Size = New Size(331, 63)
        Panel7.TabIndex = 0
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(59, 18)
        Label6.Name = "Label6"
        Label6.Size = New Size(177, 26)
        Label6.TabIndex = 1
        Label6.Text = "Achiving Lessons"
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Image = My.Resources.Resources.icons8_play_50
        PictureBox4.Location = New Point(3, 3)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(51, 53)
        PictureBox4.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox4.TabIndex = 0
        PictureBox4.TabStop = False
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label4.AutoSize = True
        Label4.Font = New Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(4, 195)
        Label4.Name = "Label4"
        Label4.Size = New Size(347, 64)
        Label4.TabIndex = 2
        Label4.Text = "Filling and Archiving Lessons"
        Label4.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Panel3
        ' 
        Panel3.Controls.Add(Panel4)
        Panel3.Controls.Add(Panel2)
        Panel3.Location = New Point(4, 4)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(338, 187)
        Panel3.TabIndex = 1
        ' 
        ' Panel4
        ' 
        Panel4.Controls.Add(Label3)
        Panel4.Controls.Add(PictureBox2)
        Panel4.Location = New Point(4, 72)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(331, 63)
        Panel4.TabIndex = 2
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(59, 18)
        Label3.Name = "Label3"
        Label3.Size = New Size(269, 26)
        Label3.TabIndex = 1
        Label3.Text = "Processing Student Leaving"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = My.Resources.Resources.icons8_play_50
        PictureBox2.Location = New Point(3, 3)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(51, 53)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 0
        PictureBox2.TabStop = False
        ' 
        ' Panel2
        ' 
        Panel2.Controls.Add(Label2)
        Panel2.Controls.Add(PictureBox1)
        Panel2.Location = New Point(3, 3)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(331, 63)
        Panel2.TabIndex = 0
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(59, 18)
        Label2.Name = "Label2"
        Label2.Size = New Size(269, 26)
        Label2.TabIndex = 1
        Label2.Text = "Processing Student Leaving"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.icons8_play_50
        PictureBox1.Location = New Point(3, 3)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(51, 53)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' Processingltudentleaving
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.MediumTurquoise
        ClientSize = New Size(1087, 782)
        Controls.Add(TableLayoutPanel3)
        Controls.Add(Panel1)
        Controls.Add(TableLayoutPanel2)
        Name = "Processingltudentleaving"
        Text = "Processingltudentleaving"
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel1.PerformLayout()
        TableLayoutPanel2.ResumeLayout(False)
        TableLayoutPanel2.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        TableLayoutPanel3.ResumeLayout(False)
        TableLayoutPanel3.PerformLayout()
        Panel8.ResumeLayout(False)
        Panel8.PerformLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        Panel5.ResumeLayout(False)
        Panel5.PerformLayout()
        Panel6.ResumeLayout(False)
        Panel6.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        Panel7.ResumeLayout(False)
        Panel7.PerformLayout()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        Panel3.ResumeLayout(False)
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents InstructorProfiles As LinkLabel
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents LinkLabel3 As LinkLabel
    Friend WithEvents LinkLabel5 As LinkLabel
    Friend WithEvents LinkLabel6 As LinkLabel
    Friend WithEvents LinkLabel4 As LinkLabel
    Friend WithEvents Studentdetailslink As LinkLabel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Label7 As Label
    Friend WithEvents CheckBox3 As CheckBox
End Class
