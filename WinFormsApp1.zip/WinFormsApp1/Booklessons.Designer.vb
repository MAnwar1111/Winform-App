﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Booklessons
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TableLayoutPanel1 = New TableLayoutPanel()
        LinkLabel1 = New LinkLabel()
        InstructorProfiles = New LinkLabel()
        TableLayoutPanel2 = New TableLayoutPanel()
        LinkLabel2 = New LinkLabel()
        LinkLabel3 = New LinkLabel()
        TableLayoutPanel3 = New TableLayoutPanel()
        Dashboard = New LinkLabel()
        Studentdetailpage = New LinkLabel()
        ViewReport = New LinkLabel()
        AutomatedProcesses = New LinkLabel()
        BookedLessons = New LinkLabel()
        Studentdetailslink = New LinkLabel()
        TableLayoutPanel4 = New TableLayoutPanel()
        Panel1 = New Panel()
        Panel4 = New Panel()
        CheckBox4 = New CheckBox()
        CheckBox5 = New CheckBox()
        CheckBox6 = New CheckBox()
        Label5 = New Label()
        Panel3 = New Panel()
        PictureBox2 = New PictureBox()
        TextBox1 = New TextBox()
        Label4 = New Label()
        PictureBox1 = New PictureBox()
        Panel2 = New Panel()
        CheckBox1 = New CheckBox()
        CheckBox2 = New CheckBox()
        CheckBox3 = New CheckBox()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        Label6 = New Label()
        Panel5 = New Panel()
        Label9 = New Label()
        Button2 = New Button()
        Button1 = New Button()
        Label8 = New Label()
        Label7 = New Label()
        Panel6 = New Panel()
        Label12 = New Label()
        Label10 = New Label()
        Label11 = New Label()
        TableLayoutPanel1.SuspendLayout()
        TableLayoutPanel2.SuspendLayout()
        TableLayoutPanel3.SuspendLayout()
        TableLayoutPanel4.SuspendLayout()
        Panel1.SuspendLayout()
        Panel4.SuspendLayout()
        Panel3.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel2.SuspendLayout()
        Panel5.SuspendLayout()
        Panel6.SuspendLayout()
        SuspendLayout()
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel1.ColumnCount = 1
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel1.Controls.Add(LinkLabel1, 0, 0)
        TableLayoutPanel1.Location = New Point(0, 0)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 2
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel1.Size = New Size(200, 100)
        TableLayoutPanel1.TabIndex = 0
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel1.AutoSize = True
        LinkLabel1.Cursor = Cursors.Hand
        LinkLabel1.Font = New Font("Times New Roman", 12F)
        LinkLabel1.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel1.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel1.LinkColor = Color.Black
        LinkLabel1.Location = New Point(15, 9)
        LinkLabel1.Margin = New Padding(14, 8, 14, 8)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(170, 4)
        LinkLabel1.TabIndex = 0
        LinkLabel1.TabStop = True
        LinkLabel1.Text = "Dashboard"
        LinkLabel1.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' InstructorProfiles
        ' 
        InstructorProfiles.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        InstructorProfiles.AutoSize = True
        InstructorProfiles.Cursor = Cursors.Hand
        InstructorProfiles.Font = New Font("Times New Roman", 12F)
        InstructorProfiles.ForeColor = SystemColors.ActiveCaptionText
        InstructorProfiles.LinkBehavior = LinkBehavior.HoverUnderline
        InstructorProfiles.LinkColor = Color.Black
        InstructorProfiles.Location = New Point(15, 49)
        InstructorProfiles.Margin = New Padding(14, 8, 14, 8)
        InstructorProfiles.Name = "InstructorProfiles"
        InstructorProfiles.Size = New Size(170, 42)
        InstructorProfiles.TabIndex = 2
        InstructorProfiles.TabStop = True
        InstructorProfiles.Text = "Instructor Profiles"
        InstructorProfiles.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' TableLayoutPanel2
        ' 
        TableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel2.ColumnCount = 1
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel2.Controls.Add(LinkLabel2, 0, 0)
        TableLayoutPanel2.Location = New Point(0, 0)
        TableLayoutPanel2.Name = "TableLayoutPanel2"
        TableLayoutPanel2.RowCount = 2
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
        TableLayoutPanel2.Size = New Size(200, 100)
        TableLayoutPanel2.TabIndex = 0
        ' 
        ' LinkLabel2
        ' 
        LinkLabel2.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel2.AutoSize = True
        LinkLabel2.Cursor = Cursors.Hand
        LinkLabel2.Font = New Font("Times New Roman", 12F)
        LinkLabel2.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel2.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel2.LinkColor = Color.Black
        LinkLabel2.Location = New Point(15, 9)
        LinkLabel2.Margin = New Padding(14, 8, 14, 8)
        LinkLabel2.Name = "LinkLabel2"
        LinkLabel2.Size = New Size(170, 4)
        LinkLabel2.TabIndex = 0
        LinkLabel2.TabStop = True
        LinkLabel2.Text = "Dashboard"
        LinkLabel2.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' LinkLabel3
        ' 
        LinkLabel3.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel3.AutoSize = True
        LinkLabel3.Cursor = Cursors.Hand
        LinkLabel3.Font = New Font("Times New Roman", 12F)
        LinkLabel3.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel3.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel3.LinkColor = Color.Black
        LinkLabel3.Location = New Point(15, 49)
        LinkLabel3.Margin = New Padding(14, 8, 14, 8)
        LinkLabel3.Name = "LinkLabel3"
        LinkLabel3.Size = New Size(170, 42)
        LinkLabel3.TabIndex = 2
        LinkLabel3.TabStop = True
        LinkLabel3.Text = "Instructor Profiles"
        LinkLabel3.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' TableLayoutPanel3
        ' 
        TableLayoutPanel3.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel3.ColumnCount = 1
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel3.Controls.Add(Dashboard, 0, 0)
        TableLayoutPanel3.Controls.Add(Studentdetailpage, 0, 2)
        TableLayoutPanel3.Controls.Add(ViewReport, 0, 4)
        TableLayoutPanel3.Controls.Add(AutomatedProcesses, 0, 5)
        TableLayoutPanel3.Controls.Add(BookedLessons, 0, 1)
        TableLayoutPanel3.Controls.Add(Studentdetailslink, 0, 3)
        TableLayoutPanel3.ForeColor = Color.Black
        TableLayoutPanel3.Location = New Point(13, 13)
        TableLayoutPanel3.Margin = New Padding(4)
        TableLayoutPanel3.Name = "TableLayoutPanel3"
        TableLayoutPanel3.RowCount = 7
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 10.8225107F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.Percent, 35.0649338F))
        TableLayoutPanel3.Size = New Size(267, 746)
        TableLayoutPanel3.TabIndex = 1
        ' 
        ' Dashboard
        ' 
        Dashboard.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Dashboard.AutoSize = True
        Dashboard.Cursor = Cursors.Hand
        Dashboard.Font = New Font("Times New Roman", 12F)
        Dashboard.ForeColor = SystemColors.ActiveCaptionText
        Dashboard.LinkBehavior = LinkBehavior.HoverUnderline
        Dashboard.LinkColor = Color.Black
        Dashboard.Location = New Point(15, 9)
        Dashboard.Margin = New Padding(14, 8, 14, 8)
        Dashboard.Name = "Dashboard"
        Dashboard.Size = New Size(237, 63)
        Dashboard.TabIndex = 0
        Dashboard.TabStop = True
        Dashboard.Text = "Dashboard"
        Dashboard.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Studentdetailpage
        ' 
        Studentdetailpage.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Studentdetailpage.AutoSize = True
        Studentdetailpage.Cursor = Cursors.Hand
        Studentdetailpage.Font = New Font("Times New Roman", 12F)
        Studentdetailpage.ForeColor = SystemColors.ActiveCaptionText
        Studentdetailpage.LinkBehavior = LinkBehavior.HoverUnderline
        Studentdetailpage.LinkColor = Color.Black
        Studentdetailpage.Location = New Point(15, 169)
        Studentdetailpage.Margin = New Padding(14, 8, 14, 8)
        Studentdetailpage.Name = "Studentdetailpage"
        Studentdetailpage.Size = New Size(237, 63)
        Studentdetailpage.TabIndex = 2
        Studentdetailpage.TabStop = True
        Studentdetailpage.Text = "Instructor Profiles"
        Studentdetailpage.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' ViewReport
        ' 
        ViewReport.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        ViewReport.AutoSize = True
        ViewReport.Cursor = Cursors.Hand
        ViewReport.Font = New Font("Times New Roman", 12F)
        ViewReport.ForeColor = SystemColors.ActiveCaptionText
        ViewReport.LinkBehavior = LinkBehavior.HoverUnderline
        ViewReport.LinkColor = Color.Black
        ViewReport.Location = New Point(15, 329)
        ViewReport.Margin = New Padding(14, 8, 14, 8)
        ViewReport.Name = "ViewReport"
        ViewReport.Size = New Size(237, 63)
        ViewReport.TabIndex = 4
        ViewReport.TabStop = True
        ViewReport.Text = "View Reports/Analytics"
        ViewReport.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' AutomatedProcesses
        ' 
        AutomatedProcesses.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        AutomatedProcesses.AutoSize = True
        AutomatedProcesses.Cursor = Cursors.Hand
        AutomatedProcesses.Font = New Font("Times New Roman", 12F)
        AutomatedProcesses.ForeColor = SystemColors.ActiveCaptionText
        AutomatedProcesses.LinkBehavior = LinkBehavior.HoverUnderline
        AutomatedProcesses.LinkColor = Color.Black
        AutomatedProcesses.Location = New Point(15, 409)
        AutomatedProcesses.Margin = New Padding(14, 8, 14, 8)
        AutomatedProcesses.Name = "AutomatedProcesses"
        AutomatedProcesses.Size = New Size(237, 63)
        AutomatedProcesses.TabIndex = 5
        AutomatedProcesses.TabStop = True
        AutomatedProcesses.Text = "Automated Processes"
        AutomatedProcesses.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' BookedLessons
        ' 
        BookedLessons.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        BookedLessons.AutoSize = True
        BookedLessons.Cursor = Cursors.Hand
        BookedLessons.Font = New Font("Times New Roman", 12F)
        BookedLessons.ForeColor = SystemColors.ActiveCaptionText
        BookedLessons.LinkBehavior = LinkBehavior.HoverUnderline
        BookedLessons.LinkColor = Color.Black
        BookedLessons.Location = New Point(15, 89)
        BookedLessons.Margin = New Padding(14, 8, 14, 8)
        BookedLessons.Name = "BookedLessons"
        BookedLessons.Size = New Size(237, 63)
        BookedLessons.TabIndex = 3
        BookedLessons.TabStop = True
        BookedLessons.Text = "Book Lessons"
        BookedLessons.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Studentdetailslink
        ' 
        Studentdetailslink.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Studentdetailslink.AutoSize = True
        Studentdetailslink.Cursor = Cursors.Hand
        Studentdetailslink.Font = New Font("Times New Roman", 12F)
        Studentdetailslink.ForeColor = SystemColors.ActiveCaptionText
        Studentdetailslink.LinkBehavior = LinkBehavior.HoverUnderline
        Studentdetailslink.LinkColor = Color.Black
        Studentdetailslink.Location = New Point(15, 249)
        Studentdetailslink.Margin = New Padding(14, 8, 14, 8)
        Studentdetailslink.Name = "Studentdetailslink"
        Studentdetailslink.Size = New Size(237, 63)
        Studentdetailslink.TabIndex = 1
        Studentdetailslink.TabStop = True
        Studentdetailslink.Text = "Student Profiles"
        Studentdetailslink.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' TableLayoutPanel4
        ' 
        TableLayoutPanel4.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel4.ColumnCount = 2
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 74.1666641F))
        TableLayoutPanel4.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25.8333378F))
        TableLayoutPanel4.Controls.Add(Panel1, 0, 1)
        TableLayoutPanel4.Controls.Add(Label1, 0, 0)
        TableLayoutPanel4.Controls.Add(Label6, 0, 2)
        TableLayoutPanel4.Controls.Add(Panel5, 0, 3)
        TableLayoutPanel4.Controls.Add(Panel6, 1, 1)
        TableLayoutPanel4.Location = New Point(287, 13)
        TableLayoutPanel4.Name = "TableLayoutPanel4"
        TableLayoutPanel4.RowCount = 4
        TableLayoutPanel4.RowStyles.Add(New RowStyle(SizeType.Percent, 11.1111107F))
        TableLayoutPanel4.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel4.RowStyles.Add(New RowStyle(SizeType.Percent, 11.1111107F))
        TableLayoutPanel4.RowStyles.Add(New RowStyle(SizeType.Percent, 27.7777786F))
        TableLayoutPanel4.Size = New Size(840, 746)
        TableLayoutPanel4.TabIndex = 2
        ' 
        ' Panel1
        ' 
        Panel1.Controls.Add(Panel4)
        Panel1.Controls.Add(Label5)
        Panel1.Controls.Add(Panel3)
        Panel1.Controls.Add(Label4)
        Panel1.Controls.Add(PictureBox1)
        Panel1.Controls.Add(Panel2)
        Panel1.Controls.Add(Label3)
        Panel1.Controls.Add(Label2)
        Panel1.Location = New Point(4, 87)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(614, 364)
        Panel1.TabIndex = 1
        ' 
        ' Panel4
        ' 
        Panel4.Controls.Add(CheckBox4)
        Panel4.Controls.Add(CheckBox5)
        Panel4.Controls.Add(CheckBox6)
        Panel4.Location = New Point(45, 210)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(535, 32)
        Panel4.TabIndex = 10
        ' 
        ' CheckBox4
        ' 
        CheckBox4.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        CheckBox4.AutoSize = True
        CheckBox4.Font = New Font("Times New Roman", 12F)
        CheckBox4.Location = New Point(3, 3)
        CheckBox4.Name = "CheckBox4"
        CheckBox4.Size = New Size(95, 26)
        CheckBox4.TabIndex = 1
        CheckBox4.Text = "1 Hours"
        CheckBox4.UseVisualStyleBackColor = True
        ' 
        ' CheckBox5
        ' 
        CheckBox5.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        CheckBox5.AutoSize = True
        CheckBox5.Font = New Font("Times New Roman", 12F)
        CheckBox5.Location = New Point(206, 3)
        CheckBox5.Name = "CheckBox5"
        CheckBox5.Size = New Size(95, 26)
        CheckBox5.TabIndex = 2
        CheckBox5.Text = "2 Hours"
        CheckBox5.UseVisualStyleBackColor = True
        ' 
        ' CheckBox6
        ' 
        CheckBox6.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        CheckBox6.AutoSize = True
        CheckBox6.Font = New Font("Times New Roman", 12F)
        CheckBox6.Location = New Point(401, 3)
        CheckBox6.Name = "CheckBox6"
        CheckBox6.Size = New Size(95, 26)
        CheckBox6.TabIndex = 3
        CheckBox6.Text = "3 Hours"
        CheckBox6.UseVisualStyleBackColor = True
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(3, 181)
        Label5.Name = "Label5"
        Label5.Size = New Size(215, 26)
        Label5.TabIndex = 9
        Label5.Text = "Dureation Selection - "
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.White
        Panel3.Controls.Add(PictureBox2)
        Panel3.Controls.Add(TextBox1)
        Panel3.Font = New Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Panel3.Location = New Point(227, 127)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(353, 37)
        Panel3.TabIndex = 8
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = My.Resources.Resources.icons8_down_67
        PictureBox2.Location = New Point(311, 3)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(39, 31)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 1
        PictureBox2.TabStop = False
        ' 
        ' TextBox1
        ' 
        TextBox1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        TextBox1.BorderStyle = BorderStyle.None
        TextBox1.ForeColor = Color.Gray
        TextBox1.Location = New Point(20, 7)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(285, 23)
        TextBox1.TabIndex = 0
        TextBox1.Text = "Instructor Name"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(4, 131)
        Label4.Name = "Label4"
        Label4.Size = New Size(214, 26)
        Label4.TabIndex = 7
        Label4.Text = "Instructor Selection - "
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.icons8_calender_64
        PictureBox1.Location = New Point(227, 84)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(28, 26)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 6
        PictureBox1.TabStop = False
        ' 
        ' Panel2
        ' 
        Panel2.Controls.Add(CheckBox1)
        Panel2.Controls.Add(CheckBox2)
        Panel2.Controls.Add(CheckBox3)
        Panel2.Location = New Point(45, 33)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(535, 32)
        Panel2.TabIndex = 5
        ' 
        ' CheckBox1
        ' 
        CheckBox1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        CheckBox1.AutoSize = True
        CheckBox1.Font = New Font("Times New Roman", 12F)
        CheckBox1.Location = New Point(3, 3)
        CheckBox1.Name = "CheckBox1"
        CheckBox1.Size = New Size(128, 26)
        CheckBox1.TabIndex = 1
        CheckBox1.Text = "Introductory"
        CheckBox1.UseVisualStyleBackColor = True
        ' 
        ' CheckBox2
        ' 
        CheckBox2.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        CheckBox2.AutoSize = True
        CheckBox2.Font = New Font("Times New Roman", 12F)
        CheckBox2.Location = New Point(206, 3)
        CheckBox2.Name = "CheckBox2"
        CheckBox2.Size = New Size(107, 26)
        CheckBox2.TabIndex = 2
        CheckBox2.Text = "Pass Plus"
        CheckBox2.UseVisualStyleBackColor = True
        ' 
        ' CheckBox3
        ' 
        CheckBox3.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        CheckBox3.AutoSize = True
        CheckBox3.Font = New Font("Times New Roman", 12F)
        CheckBox3.Location = New Point(401, 3)
        CheckBox3.Name = "CheckBox3"
        CheckBox3.Size = New Size(131, 26)
        CheckBox3.TabIndex = 3
        CheckBox3.Text = "Driving Test"
        CheckBox3.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(3, 84)
        Label3.Name = "Label3"
        Label3.Size = New Size(218, 26)
        Label3.TabIndex = 4
        Label3.Text = "Date & Time Selection -"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(3, 4)
        Label2.Name = "Label2"
        Label2.Size = New Size(136, 26)
        Label2.TabIndex = 0
        Label2.Text = "Lesson Type-"
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label1.AutoSize = True
        Label1.Font = New Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(4, 1)
        Label1.Name = "Label1"
        Label1.Size = New Size(217, 82)
        Label1.TabIndex = 0
        Label1.Text = "Lesson Bookings"
        Label1.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Label6
        ' 
        Label6.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left
        Label6.AutoSize = True
        Label6.Font = New Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(4, 455)
        Label6.Name = "Label6"
        Label6.Size = New Size(286, 82)
        Label6.TabIndex = 2
        Label6.Text = "Additional Information"
        Label6.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Panel5
        ' 
        Panel5.Controls.Add(Label9)
        Panel5.Controls.Add(Button2)
        Panel5.Controls.Add(Button1)
        Panel5.Controls.Add(Label8)
        Panel5.Controls.Add(Label7)
        Panel5.Location = New Point(4, 541)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(614, 201)
        Panel5.TabIndex = 4
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(4, 48)
        Label9.Name = "Label9"
        Label9.Size = New Size(276, 26)
        Label9.TabIndex = 6
        Label9.Text = "If any specific requirement -"
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(343, 104)
        Button2.Name = "Button2"
        Button2.Padding = New Padding(10, 5, 10, 5)
        Button2.Size = New Size(115, 41)
        Button2.TabIndex = 5
        Button2.Text = "Cancel"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(142, 104)
        Button1.Name = "Button1"
        Button1.Padding = New Padding(10, 5, 10, 5)
        Button1.Size = New Size(115, 41)
        Button1.TabIndex = 3
        Button1.Text = "Submit"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(424, 0)
        Label8.Name = "Label8"
        Label8.Size = New Size(166, 26)
        Label8.TabIndex = 4
        Label8.Text = "Contact Details -"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(4, 0)
        Label7.Name = "Label7"
        Label7.Size = New Size(157, 26)
        Label7.TabIndex = 3
        Label7.Text = "Student Name -"
        ' 
        ' Panel6
        ' 
        Panel6.Controls.Add(Label12)
        Panel6.Controls.Add(Label10)
        Panel6.Location = New Point(625, 87)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(211, 364)
        Panel6.TabIndex = 6
        ' 
        ' Label12
        ' 
        Label12.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        Label12.AutoSize = True
        Label12.Font = New Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(82, 138)
        Label12.Name = "Label12"
        Label12.Size = New Size(45, 26)
        Label12.TabIndex = 6
        Label12.Text = "$25"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(3, 4)
        Label10.Name = "Label10"
        Label10.Size = New Size(210, 33)
        Label10.TabIndex = 5
        Label10.Text = "Total cost for the "
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label11.Location = New Point(915, 137)
        Label11.Name = "Label11"
        Label11.Size = New Size(200, 33)
        Label11.TabIndex = 6
        Label11.Text = "selected session:"
        ' 
        ' Booklessons
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.MediumTurquoise
        ClientSize = New Size(1563, 816)
        Controls.Add(Label11)
        Controls.Add(TableLayoutPanel4)
        Controls.Add(TableLayoutPanel3)
        Name = "Booklessons"
        Text = "Form1"
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel1.PerformLayout()
        TableLayoutPanel2.ResumeLayout(False)
        TableLayoutPanel2.PerformLayout()
        TableLayoutPanel3.ResumeLayout(False)
        TableLayoutPanel3.PerformLayout()
        TableLayoutPanel4.ResumeLayout(False)
        TableLayoutPanel4.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel5.ResumeLayout(False)
        Panel5.PerformLayout()
        Panel6.ResumeLayout(False)
        Panel6.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents InstructorProfiles As LinkLabel
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents LinkLabel3 As LinkLabel
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents Dashboard As LinkLabel
    Friend WithEvents Studentdetailpage As LinkLabel
    Friend WithEvents ViewReport As LinkLabel
    Friend WithEvents AutomatedProcesses As LinkLabel
    Friend WithEvents BookedLessons As LinkLabel
    Friend WithEvents Studentdetailslink As LinkLabel
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents CheckBox4 As CheckBox
    Friend WithEvents CheckBox5 As CheckBox
    Friend WithEvents CheckBox6 As CheckBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label10 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
End Class
