﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Studentprogress
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TableLayoutPanel1 = New TableLayoutPanel()
        LinkLabel1 = New LinkLabel()
        InstructorProfiles = New LinkLabel()
        LinkLabel5 = New LinkLabel()
        LinkLabel6 = New LinkLabel()
        LinkLabel4 = New LinkLabel()
        Studentdetailslink = New LinkLabel()
        Panel1 = New Panel()
        Label1 = New Label()
        TableLayoutPanel2 = New TableLayoutPanel()
        Panel2 = New Panel()
        Label2 = New Label()
        PictureBox1 = New PictureBox()
        Label3 = New Label()
        Panel3 = New Panel()
        PictureBox2 = New PictureBox()
        LinkLabel2 = New LinkLabel()
        TableLayoutPanel1.SuspendLayout()
        Panel1.SuspendLayout()
        TableLayoutPanel2.SuspendLayout()
        Panel2.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel3.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel1.ColumnCount = 1
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel1.Controls.Add(LinkLabel1, 0, 0)
        TableLayoutPanel1.Controls.Add(InstructorProfiles, 0, 2)
        TableLayoutPanel1.Controls.Add(LinkLabel5, 0, 4)
        TableLayoutPanel1.Controls.Add(LinkLabel6, 0, 5)
        TableLayoutPanel1.Controls.Add(LinkLabel4, 0, 1)
        TableLayoutPanel1.Controls.Add(Studentdetailslink, 0, 3)
        TableLayoutPanel1.ForeColor = Color.Black
        TableLayoutPanel1.Location = New Point(13, 13)
        TableLayoutPanel1.Margin = New Padding(4)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 7
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.8225107F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 10.82251F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 35.0649338F))
        TableLayoutPanel1.Size = New Size(267, 746)
        TableLayoutPanel1.TabIndex = 1
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel1.AutoSize = True
        LinkLabel1.Cursor = Cursors.Hand
        LinkLabel1.Font = New Font("Times New Roman", 12F)
        LinkLabel1.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel1.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel1.LinkColor = Color.Black
        LinkLabel1.Location = New Point(15, 9)
        LinkLabel1.Margin = New Padding(14, 8, 14, 8)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(237, 63)
        LinkLabel1.TabIndex = 0
        LinkLabel1.TabStop = True
        LinkLabel1.Text = "Dashboard"
        LinkLabel1.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' InstructorProfiles
        ' 
        InstructorProfiles.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        InstructorProfiles.AutoSize = True
        InstructorProfiles.Cursor = Cursors.Hand
        InstructorProfiles.Font = New Font("Times New Roman", 12F)
        InstructorProfiles.ForeColor = SystemColors.ActiveCaptionText
        InstructorProfiles.LinkBehavior = LinkBehavior.HoverUnderline
        InstructorProfiles.LinkColor = Color.Black
        InstructorProfiles.Location = New Point(15, 169)
        InstructorProfiles.Margin = New Padding(14, 8, 14, 8)
        InstructorProfiles.Name = "InstructorProfiles"
        InstructorProfiles.Size = New Size(237, 63)
        InstructorProfiles.TabIndex = 2
        InstructorProfiles.TabStop = True
        InstructorProfiles.Text = "Instructor Profiles"
        InstructorProfiles.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' LinkLabel5
        ' 
        LinkLabel5.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel5.AutoSize = True
        LinkLabel5.Cursor = Cursors.Hand
        LinkLabel5.Font = New Font("Times New Roman", 12F)
        LinkLabel5.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel5.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel5.LinkColor = Color.Black
        LinkLabel5.Location = New Point(15, 329)
        LinkLabel5.Margin = New Padding(14, 8, 14, 8)
        LinkLabel5.Name = "LinkLabel5"
        LinkLabel5.Size = New Size(237, 63)
        LinkLabel5.TabIndex = 4
        LinkLabel5.TabStop = True
        LinkLabel5.Text = "View Reports/Analytics"
        LinkLabel5.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' LinkLabel6
        ' 
        LinkLabel6.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel6.AutoSize = True
        LinkLabel6.Cursor = Cursors.Hand
        LinkLabel6.Font = New Font("Times New Roman", 12F)
        LinkLabel6.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel6.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel6.LinkColor = Color.Black
        LinkLabel6.Location = New Point(15, 409)
        LinkLabel6.Margin = New Padding(14, 8, 14, 8)
        LinkLabel6.Name = "LinkLabel6"
        LinkLabel6.Size = New Size(237, 63)
        LinkLabel6.TabIndex = 5
        LinkLabel6.TabStop = True
        LinkLabel6.Text = "Automated Processes"
        LinkLabel6.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' LinkLabel4
        ' 
        LinkLabel4.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        LinkLabel4.AutoSize = True
        LinkLabel4.Cursor = Cursors.Hand
        LinkLabel4.Font = New Font("Times New Roman", 12F)
        LinkLabel4.ForeColor = SystemColors.ActiveCaptionText
        LinkLabel4.LinkBehavior = LinkBehavior.HoverUnderline
        LinkLabel4.LinkColor = Color.Black
        LinkLabel4.Location = New Point(15, 89)
        LinkLabel4.Margin = New Padding(14, 8, 14, 8)
        LinkLabel4.Name = "LinkLabel4"
        LinkLabel4.Size = New Size(237, 63)
        LinkLabel4.TabIndex = 3
        LinkLabel4.TabStop = True
        LinkLabel4.Text = "Book Lessons"
        LinkLabel4.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Studentdetailslink
        ' 
        Studentdetailslink.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Studentdetailslink.AutoSize = True
        Studentdetailslink.Cursor = Cursors.Hand
        Studentdetailslink.Font = New Font("Times New Roman", 12F)
        Studentdetailslink.ForeColor = SystemColors.ActiveCaptionText
        Studentdetailslink.LinkBehavior = LinkBehavior.HoverUnderline
        Studentdetailslink.LinkColor = Color.Black
        Studentdetailslink.Location = New Point(15, 249)
        Studentdetailslink.Margin = New Padding(14, 8, 14, 8)
        Studentdetailslink.Name = "Studentdetailslink"
        Studentdetailslink.Size = New Size(237, 63)
        Studentdetailslink.TabIndex = 1
        Studentdetailslink.TabStop = True
        Studentdetailslink.Text = "Student Profiles"
        Studentdetailslink.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Panel1
        ' 
        Panel1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(287, 13)
        Panel1.Margin = New Padding(3, 4, 3, 4)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(768, 89)
        Panel1.TabIndex = 3
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(3, 30)
        Label1.Name = "Label1"
        Label1.Size = New Size(203, 33)
        Label1.TabIndex = 0
        Label1.Text = "Student Progress"
        Label1.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' TableLayoutPanel2
        ' 
        TableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        TableLayoutPanel2.ColumnCount = 1
        TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100F))
        TableLayoutPanel2.Controls.Add(Panel2, 0, 0)
        TableLayoutPanel2.Controls.Add(Label3, 0, 1)
        TableLayoutPanel2.Controls.Add(Panel3, 0, 2)
        TableLayoutPanel2.Location = New Point(287, 109)
        TableLayoutPanel2.Name = "TableLayoutPanel2"
        TableLayoutPanel2.RowCount = 3
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 50F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 10F))
        TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 40F))
        TableLayoutPanel2.Size = New Size(768, 650)
        TableLayoutPanel2.TabIndex = 4
        ' 
        ' Panel2
        ' 
        Panel2.Controls.Add(Label2)
        Panel2.Controls.Add(PictureBox1)
        Panel2.Location = New Point(4, 4)
        Panel2.Name = "Panel2"
        Panel2.Padding = New Padding(5)
        Panel2.Size = New Size(760, 317)
        Panel2.TabIndex = 0
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.White
        Label2.BorderStyle = BorderStyle.FixedSingle
        Label2.Enabled = False
        Label2.FlatStyle = FlatStyle.Popup
        Label2.Font = New Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = SystemColors.ControlText
        Label2.Location = New Point(48, 246)
        Label2.Name = "Label2"
        Label2.Size = New Size(429, 36)
        Label2.TabIndex = 1
        Label2.Text = "Graphs displaying studnet progress"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.chart
        PictureBox1.Location = New Point(48, 13)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(429, 208)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Label3.AutoSize = True
        Label3.Font = New Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(4, 325)
        Label3.Name = "Label3"
        Label3.Size = New Size(760, 64)
        Label3.TabIndex = 1
        Label3.Text = "Custome Report Genreration"
        Label3.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Panel3
        ' 
        Panel3.Controls.Add(PictureBox2)
        Panel3.Controls.Add(LinkLabel2)
        Panel3.Location = New Point(4, 393)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(760, 84)
        Panel3.TabIndex = 6
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = My.Resources.Resources.icons8_down_67__1_
        PictureBox2.Location = New Point(26, 30)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(42, 40)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 3
        PictureBox2.TabStop = False
        ' 
        ' LinkLabel2
        ' 
        LinkLabel2.AutoSize = True
        LinkLabel2.Font = New Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        LinkLabel2.LinkBehavior = LinkBehavior.NeverUnderline
        LinkLabel2.LinkColor = Color.Black
        LinkLabel2.Location = New Point(74, 30)
        LinkLabel2.Name = "LinkLabel2"
        LinkLabel2.Size = New Size(116, 22)
        LinkLabel2.TabIndex = 2
        LinkLabel2.TabStop = True
        LinkLabel2.Text = "Export report"
        ' 
        ' Studentprogress
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.MediumTurquoise
        ClientSize = New Size(1091, 764)
        Controls.Add(TableLayoutPanel2)
        Controls.Add(Panel1)
        Controls.Add(TableLayoutPanel1)
        Name = "Studentprogress"
        Text = "Form1"
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel1.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        TableLayoutPanel2.ResumeLayout(False)
        TableLayoutPanel2.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents InstructorProfiles As LinkLabel
    Friend WithEvents LinkLabel5 As LinkLabel
    Friend WithEvents LinkLabel6 As LinkLabel
    Friend WithEvents LinkLabel4 As LinkLabel
    Friend WithEvents Studentdetailslink As LinkLabel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents LinkLabel2 As LinkLabel
End Class
