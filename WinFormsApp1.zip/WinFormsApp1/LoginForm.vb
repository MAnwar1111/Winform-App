﻿Public Class LoginForm
    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked

    End Sub

    Private Sub RoundButton_Click(sender As Object, e As EventArgs)
        MessageBox.Show("Round button clicked!")
    End Sub

    Private Sub SigninBtn_Click(sender As Object, e As EventArgs) Handles SigninBtn.Click
        ' Hide the current form (Form1)
        Me.Hide()

        ' Create an instance of Form2 and show it
        Dim form2 As New Dashboard()
        form2.Show()
    End Sub
End Class
