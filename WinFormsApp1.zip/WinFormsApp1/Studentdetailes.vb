﻿Public Class Studentdetailes
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Studentdetailes_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Studentdetailslink.LinkClicked
        ' Hide the current form (Form1)
        Me.Hide()

        ' Create an instance of Form2 and show it
        Dim form2 As New studentdetailes()
        form2.Show()
    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles InstructorProfiles.LinkClicked

        ' Hide the current form (Form1)
        Me.Hide()

        ' Create an instance of Form2 and show it
        Dim form2 As New Instructuredetails()
        form2.Show()
    End Sub
End Class